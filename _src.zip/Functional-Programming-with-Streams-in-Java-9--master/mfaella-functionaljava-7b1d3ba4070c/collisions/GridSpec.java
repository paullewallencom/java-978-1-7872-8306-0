package collisions;

public class GridSpec {
	public int rows, cols, rowHeight, colWidth;
}
